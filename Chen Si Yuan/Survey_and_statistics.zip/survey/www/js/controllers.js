angular.module('app.controllers', [])
  
.controller('surveyCtrl', function($scope) {

})
   
.controller('survey2Ctrl', function($scope) {

})
   
.controller('statisticsCtrl', function($scope) {

})
 